#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <signal.h>
#include <time.h>
#include <stdlib.h>
#include <unistd.h>

int main(int argc, char const *argv[])
{
    int tube[2];pipe(tube);int temp;
    int s=0;
    for (int i = 2; i < argc; i++)
    {
        if (fork()==0)
        {
            dup2(tube[1],1);
            execlp("grep","grep","-c",argv[1],argv[i],NULL);
        }
    }
    int test = 5;
    write(tube[1], &test, sizeof(int));
    for (int i = 0; i < argc-2; i++){
        {
            read(tube[0],&temp,sizeof(int));
            printf("temp=%d\n",temp);
            s+=temp;
        }
    }
    printf("s=%d",s);

    
    return 0;
}
