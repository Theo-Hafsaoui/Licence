#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <signal.h>
#include <time.h>
#include <stdlib.h>
#include <math.h>

typedef int Semaphore[2];

void initSem(Semaphore S, int n) {
    int temp;
    srand(time(NULL));
    for (int i = 0; i < n; i++)
    {
        temp=42;
         write(S[1], &temp, sizeof(int));
    }
    
}

void v(Semaphore S){
    int m=42;
    write(S[1], &m, sizeof(int));
}

void p(Semaphore S){
    int m=42;
    read(S[0], &m, sizeof(int));
}

int main(int argc, char const *argv[])
{
    Semaphore s;
    int temp;srand(time(NULL));
    for (int i = 0; i < (atoi(argv[1])+atoi(argv[2])); i++)
    {
       if (fork()==0)
       {
           temp=rand();
           printf("vol numero %d souhaite atterir", getppid());
           sleep(temp);
           p(s);
           printf('vole %d est en phase d\' aterrisage', getpid())  
       }
       
   }
   
}
