typedef enum {
    TRUE  = 1,
    FALSE = 0
} tbool;

tbool EstPalindrome(char *phrase);