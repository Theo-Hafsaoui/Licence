typedef unsigned short ushort;

void TriSelection(int *liste, ushort n);