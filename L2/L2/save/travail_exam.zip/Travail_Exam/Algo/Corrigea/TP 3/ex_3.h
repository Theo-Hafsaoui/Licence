uint PairOuImpair(uint n);

uint syracuse(uint u0);

void analyse(uint u0, int *temps, int *altitude);