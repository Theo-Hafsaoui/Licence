typedef unsigned int uint;

void Echanger(int *T, uint a, uint b);

int Tamiser(int *T, uint i, uint n);

int Entasser(int *T, uint n);

int TriTas(int *T, uint n);

int *generate_perms(int n);