float Eval_Naif(float *P, float a);
float Eval_SM(float *P, float a);
float Eval_Horner(float *P, float a);