int SquareMultiply(uint x, uint k);
int Exp(int x, int i);