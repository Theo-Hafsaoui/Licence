uint Increment(uint * A, unsigned char n, unsigned char b);
uint test(unsigned char n, unsigned char b);