typedef unsigned long long int ullong;

int *generate_perms(int n);

int *generate_list(int n, int max);

void show_list(int *L, int n);

int IdxMin(int *L, int a, int b);

int TriSelection(int *T, int n);

int TriBulles(int *L, int n);

int TriInsertion(int *T, int n);