uint *S2L(char *chaine);

char *L2S(uint *liste);