uint *Addition(uint *A, uint size_A, uint *B, uint size_B, uint base);

uint *Multiplication(uint *A, uint size_A, uint *B, uint size_B, uint base);