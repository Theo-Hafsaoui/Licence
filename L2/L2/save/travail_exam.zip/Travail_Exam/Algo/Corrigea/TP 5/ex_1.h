typedef unsigned char uchar;
typedef unsigned long long int ullong;

ullong Factorielle(uchar n);