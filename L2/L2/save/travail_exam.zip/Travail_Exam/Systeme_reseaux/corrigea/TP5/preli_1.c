#include <stdio.h>
#include <unistd.h>
 
int main(void) {
    printf("Hello world");
    sleep(5);
    printf("\nBye Bye\n");
    return 0;
}