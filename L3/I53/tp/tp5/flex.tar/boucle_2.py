n = 100
for i in range(n):
    if n%2:
        j=0
        while j<n:
            j+=1
    
