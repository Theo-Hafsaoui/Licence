# Exécution
# $ ./analysePython boucle_1.py
# niveau d'imbrication max: 1

i = 0
n = int(input())
while i < n:
    i+= 1
print(n)
