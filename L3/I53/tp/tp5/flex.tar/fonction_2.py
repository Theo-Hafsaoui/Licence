# Exécution
# $ ./analysePython fonction_2.py append
# niveau d'imbrication max: 1
# fonction append: 1

L = []
for i in range(100):
    L.append ( i )

