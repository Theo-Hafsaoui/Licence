def chiffrement(m,k):
    cm=''
    for i in range(len(m)):
        chi=ord(m[i])
        ki=ord(k[(i%len(k))])
        ki=(ki-97)%26
        if(ord(m[i])!=32):
            cm+=chr((((chi+ki)-97)%26)+97)
    return cm

def dechiffrement(m,k):
    cm=''
    for i in range(len(m)):
        chi=ord(m[i])
        ki=ord(k[(i%len(k))])
        ki=(ki-97)%26
        if(ord(m[i])!=32):
            cm+=chr((((chi-ki)-97)%26)+97)
    return cm

def pgcd(l):
    for i in range(1,len(l)):
        while(l[i-1]!=l[i]):
            if(l[i-1]>(l[i])):
                l[i-1]=(l[i-1]-l[i])
            else:
                l[i]=l[i]-l[i-1]
    return (l[len(l)-1])

def decoupe(ch,k):
    l=[]
    for i in range(1,(len(ch)//k)+1):
        l.append(ch[(i-1)*k:i*k])
    return l

def Motif3(m):
    dic={}
    dici={}
    lvalue=[]
    for j in range(3):
        mc=m[j:]
        for i in range((len(mc)//3)+1):
            if(ord(mc[i])!=32):
                ki=mc[i*3:(i+1)*3]
                if not(ki in dic):
                    dic[ki]=0
                    dici[ki]=[j+i*3]
                    lvalue.append(ki)
                else:
                    dic[ki]+=1
                    dici[ki]+=[i*3]
    a=(max(dic, key=dic.get))#max de motife
    l=[]
    for i in lvalue:
        if dic[i]==dic[a]:
            l.append((i,dici[i]))
    return(l)

def distance(l):
    dis=[]
    l.sort()
    if len(l)%2==0:
        bord=len(l)//2
    else:
        bord=len(l)//2+1
    for i in range(bord):
        dis.append(l[i+1]-l[i])
    return dis

def is_prime(n):#voler sur internet la flemme de fair un test de primaliter
  if n == 2 or n == 3: return True
  if n < 2 or n%2 == 0: return False
  if n < 9: return True
  if n%3 == 0: return False
  r = int(n**0.5)
  f = 5
  while f <= r:
    if n % f == 0: return False
    if n % (f+2) == 0: return False
    f += 6
  return True    


def Primediv(n):
    l=[]
    for i in range(1,n):
        if n%i==0 and is_prime(i):
            l.append(i)
    return l

def FReq(ch,e):
    flag=True
    i=0
    while flag:
        motif=Motif3(ch)
        print("~~~~~~~~~")
        dis=distance(motif[i][1])
        pg=(pgcd(dis))
        print(Primediv(pg))
        continu=input('continue:Y/N')
        if continu=='N'or continu=='n':
            flag=False
        i+=1
def sauteMOuton(ch,k):#on utulise l'analyse frequentielle de cesare pour finir le reste
    l=[]
    for i in range((len(ch)//k)+1):
        temp=''
        for j in range(k):
            if((j+i)*k<len(ch)):
                temp+=ch[(j+i)*k]
        l.append(temp)
    return l
            
        
#------------------
m='ceciestuntestpourvoirsitoutfoncionnecorrectementnjignoresitoutvabienoupas'
k='lundi'
cm='uyhxcwtsohwzsfayiezvlduqejgomxtvekpjjgstgdkyjvcgdhbtvfwyhldgvudwogepcylocirtnzciitvfjytrwqceysijrswltikelhuqpvfpllpmkgcdyhmehzjgpxzqykujrvxtlyhwvlleuxwrvewccxvvzmmaijqcvccekgfjmtrvvlaycxvsfajtwcgnjypxvwcgzumtkpdfthiuewqpvkflnchrvvlanqmvpdmleejcfuijvrpevyaegtpkycgvfphltplfpvucwjqyhldnvvajyayuglnuxxjkxhftqvpekovkvtpdyviigxwhielfcwhbsukqaucxcgrwltqvpekyhhfefeycxj'
print(sauteMOuton(cm,5))
